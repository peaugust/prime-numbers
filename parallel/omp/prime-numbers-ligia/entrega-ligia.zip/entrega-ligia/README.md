Rodar: "./main" + numero maximo desejado

ex.: "./main 10"
